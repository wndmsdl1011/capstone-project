import React from "react";

const ProjectRegisterPage = () => {
  return <div>ProjectRegisterPage</div>;
};

export default ProjectRegisterPage;
